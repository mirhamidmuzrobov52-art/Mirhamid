
export interface EncryptedMetadata {
  originalName: string;
  mimeType: string;
  timestamp: number;
}

export interface DecryptedFile {
  data: Blob;
  name: string;
  type: string;
}

export enum AppSection {
  CREATING = 'CREATING',
  VAULT = 'VAULT'
}
