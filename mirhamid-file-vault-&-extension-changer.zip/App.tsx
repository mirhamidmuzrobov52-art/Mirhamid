
import React, { useState, useRef, useEffect } from 'react';
import { AppSection, DecryptedFile } from './types';
import { encryptFile, decryptFile } from './services/cryptoService';
import FileViewer from './components/FileViewer';

const STORAGE_KEY = 'mirhamid_vault_last_section';

const App: React.FC = () => {
  // Initialize state from localStorage if available
  const [activeSection, setActiveSection] = useState<AppSection>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === AppSection.VAULT) return AppSection.VAULT;
    return AppSection.CREATING;
  });

  const [fileToProcess, setFileToProcess] = useState<File | null>(null);
  const [newFileName, setNewFileName] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [decryptedFile, setDecryptedFile] = useState<DecryptedFile | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Persist section changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, activeSection);
  }, [activeSection]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setFileToProcess(files[0]);
      if (activeSection === AppSection.CREATING) {
        const nameWithoutExt = files[0].name.split('.').slice(0, -1).join('.');
        setNewFileName(nameWithoutExt || 'secure_file');
      }
      setError(null);
    }
  };

  const resetForm = () => {
    setFileToProcess(null);
    setNewFileName('');
    setPassword('');
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleEncrypt = async () => {
    if (!fileToProcess || !password || !newFileName) return;
    setLoading(true);
    setError(null);
    try {
      const encryptedBlob = await encryptFile(fileToProcess, password);
      const url = URL.createObjectURL(encryptedBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${newFileName}.mirhamid`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      resetForm();
    } catch (err) {
      setError('System error during encryption. Check browser compatibility.');
    } finally {
      setLoading(false);
    }
  };

  const handleDecrypt = async () => {
    if (!fileToProcess || !password) return;
    setLoading(true);
    setError(null);
    try {
      const decrypted = await decryptFile(fileToProcess, password);
      setDecryptedFile(decrypted);
      resetForm();
    } catch (err: any) {
      setError(err.message || 'Invalid credentials or corrupted container.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white selection:bg-indigo-100 selection:text-indigo-900 overflow-x-hidden">
      {/* Utility Navigation Bar */}
      <header className="bg-white border-b border-slate-100 sticky top-0 z-40 px-4 md:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="material-symbols-outlined text-indigo-600 text-2xl">shield_lock</span>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight">MirHamid Vault</h1>
        </div>
        
        <div className="flex items-center gap-2">
           <button className="p-2 rounded-full hover:bg-slate-50 text-slate-400 transition-colors">
             <span className="material-symbols-outlined text-xl">settings</span>
           </button>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 w-full max-w-6xl mx-auto p-4 md:p-8 lg:p-12">
        <div className="flex flex-col lg:flex-row gap-10 items-start">
          
          {/* Section Switcher */}
          <aside className="w-full lg:w-[260px] shrink-0">
            <div className="bg-slate-50 p-1.5 rounded-2xl flex flex-col gap-1">
              <button
                onClick={() => { setActiveSection(AppSection.CREATING); resetForm(); }}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                  activeSection === AppSection.CREATING 
                  ? 'bg-white text-indigo-600 shadow-sm border border-slate-100' 
                  : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">add_box</span>
                New Container
              </button>
              <button
                onClick={() => { setActiveSection(AppSection.VAULT); resetForm(); }}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                  activeSection === AppSection.VAULT 
                  ? 'bg-white text-indigo-600 shadow-sm border border-slate-100' 
                  : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">lock_open</span>
                Open Vault
              </button>
            </div>
          </aside>

          {/* Operation Area */}
          <div className="w-full">
            <section className="bg-white rounded-3xl border border-slate-200 overflow-hidden">
              <div className="p-6 md:p-12">
                
                {error && (
                  <div className="mb-8 p-4 bg-red-50 text-red-700 rounded-2xl border border-red-100 flex items-center gap-3">
                    <span className="material-symbols-outlined text-red-500 text-xl">error</span>
                    <span className="text-sm font-semibold">{error}</span>
                  </div>
                )}

                <div className="space-y-8">
                  {/* Dropzone */}
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className={`group cursor-pointer rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center p-12 md:p-16 ${
                      fileToProcess 
                      ? 'bg-slate-50 border-indigo-200' 
                      : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      onChange={handleFileChange} 
                      className="hidden" 
                      accept={activeSection === AppSection.VAULT ? '.mirhamid' : '*'}
                    />
                    
                    {fileToProcess ? (
                      <div className="flex flex-col items-center text-center">
                        <div className="w-16 h-16 bg-white border border-slate-100 rounded-2xl shadow-sm flex items-center justify-center text-indigo-600 mb-4">
                          <span className="material-symbols-outlined text-3xl">description</span>
                        </div>
                        <p className="text-base font-bold text-slate-800 break-all max-w-sm">{fileToProcess.name}</p>
                        <p className="text-slate-400 text-xs mt-1 font-medium uppercase">
                          {(fileToProcess.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center text-center">
                        <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 mb-4">
                          <span className="material-symbols-outlined text-3xl">upload_file</span>
                        </div>
                        <p className="text-slate-900 font-bold text-base mb-1">Select file to process</p>
                        <p className="text-slate-400 text-xs font-medium uppercase tracking-wider">
                          {activeSection === AppSection.CREATING ? 'All formats supported' : 'Upload .mirhamid only'}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Form Inputs */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {activeSection === AppSection.CREATING && (
                      <div className="space-y-2">
                        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest ml-1">Container Name</label>
                        <div className="relative">
                          <input
                            type="text"
                            value={newFileName}
                            onChange={(e) => setNewFileName(e.target.value)}
                            className="w-full h-14 bg-slate-50 border border-slate-200 rounded-xl px-4 pr-24 text-slate-900 focus:bg-white focus:border-indigo-500 transition-all font-bold outline-none"
                            placeholder="Filename"
                          />
                          <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 font-bold text-[10px] uppercase">.mirhamid</div>
                        </div>
                      </div>
                    )}

                    <div className={`space-y-2 ${activeSection === AppSection.VAULT ? 'md:col-span-2' : ''}`}>
                      <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest ml-1">Key / Password</label>
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full h-14 bg-slate-50 border border-slate-200 rounded-xl px-4 text-slate-900 focus:bg-white focus:border-indigo-500 transition-all font-bold outline-none"
                        placeholder="••••••••••••"
                      />
                    </div>
                  </div>

                  {/* Action Button */}
                  <button
                    disabled={!fileToProcess || !password || (activeSection === AppSection.CREATING && !newFileName) || loading}
                    onClick={activeSection === AppSection.CREATING ? handleEncrypt : handleDecrypt}
                    className={`w-full h-16 rounded-2xl text-white font-bold text-base transition-all flex items-center justify-center gap-4 active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed ${
                      loading 
                      ? 'bg-slate-400' 
                      : 'bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-100'
                    }`}
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <span className="material-symbols-outlined text-xl">
                          {activeSection === AppSection.CREATING ? 'lock' : 'key'}
                        </span>
                        {activeSection === AppSection.CREATING ? 'Create Container' : 'Open Vault'}
                      </>
                    )}
                  </button>
                </div>
              </div>
            </section>
          </div>
        </div>
      </main>

      {/* Simplified Footer */}
      <footer className="mt-auto w-full max-w-6xl mx-auto px-6 py-8 border-t border-slate-100 flex items-center justify-between">
        <p className="text-slate-400 text-[11px] font-bold uppercase tracking-wider">
          Local Encryption Utility
        </p>
        <div className="flex items-center gap-6">
          <span className="text-slate-300 text-[10px] font-bold uppercase tracking-widest">Privacy Secured</span>
          <span className="text-slate-300 text-[10px] font-bold uppercase tracking-widest">v2.0</span>
        </div>
      </footer>

      {decryptedFile && (
        <FileViewer 
          file={decryptedFile} 
          onClose={() => setDecryptedFile(null)} 
        />
      )}
    </div>
  );
};

export default App;
