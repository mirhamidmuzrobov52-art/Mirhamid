
import { EncryptedMetadata } from '../types';

const ALGORITHM = 'AES-GCM';
const PBKDF2_ITERATIONS = 100000;
const SALT_SIZE = 16;
const IV_SIZE = 12;

export const deriveKey = async (password: string, salt: Uint8Array): Promise<CryptoKey> => {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    'PBKDF2',
    false,
    ['deriveBits', 'deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: ALGORITHM, length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
};

export const encryptFile = async (
  file: File,
  password: string
): Promise<Blob> => {
  const salt = window.crypto.getRandomValues(new Uint8Array(SALT_SIZE));
  const iv = window.crypto.getRandomValues(new Uint8Array(IV_SIZE));
  const key = await deriveKey(password, salt);

  const metadata: EncryptedMetadata = {
    originalName: file.name,
    mimeType: file.type,
    timestamp: Date.now(),
  };

  const enc = new TextEncoder();
  const metadataBuffer = enc.encode(JSON.stringify(metadata));
  const fileBuffer = await file.arrayBuffer();

  const encryptedMetadata = await window.crypto.subtle.encrypt(
    { name: ALGORITHM, iv },
    key,
    metadataBuffer
  );

  const encryptedFile = await window.crypto.subtle.encrypt(
    { name: ALGORITHM, iv },
    key,
    fileBuffer
  );

  // Layout: [Salt 16][IV 12][MetaSize 4][EncryptedMeta][EncryptedFile]
  const metaSizeBuffer = new Uint8Array(4);
  new DataView(metaSizeBuffer.buffer).setUint32(0, encryptedMetadata.byteLength);

  return new Blob([
    salt,
    iv,
    metaSizeBuffer,
    encryptedMetadata,
    encryptedFile
  ], { type: 'application/octet-stream' });
};

export const decryptFile = async (
  blob: Blob,
  password: string
): Promise<{ data: Blob; name: string; type: string }> => {
  const buffer = await blob.arrayBuffer();
  let offset = 0;

  const salt = new Uint8Array(buffer.slice(offset, offset + SALT_SIZE));
  offset += SALT_SIZE;

  const iv = new Uint8Array(buffer.slice(offset, offset + IV_SIZE));
  offset += IV_SIZE;

  const metaSize = new DataView(buffer.slice(offset, offset + 4)).getUint32(0);
  offset += 4;

  const encryptedMetadata = buffer.slice(offset, offset + metaSize);
  offset += metaSize;

  const encryptedFile = buffer.slice(offset);

  const key = await deriveKey(password, salt);

  try {
    const decryptedMetadataBuffer = await window.crypto.subtle.decrypt(
      { name: ALGORITHM, iv },
      key,
      encryptedMetadata
    );

    const dec = new TextDecoder();
    const metadata: EncryptedMetadata = JSON.parse(dec.decode(decryptedMetadataBuffer));

    const decryptedFileBuffer = await window.crypto.subtle.decrypt(
      { name: ALGORITHM, iv },
      key,
      encryptedFile
    );

    return {
      data: new Blob([decryptedFileBuffer], { type: metadata.mimeType }),
      name: metadata.originalName,
      type: metadata.mimeType,
    };
  } catch (err) {
    throw new Error('Incorrect password or corrupted file.');
  }
};
