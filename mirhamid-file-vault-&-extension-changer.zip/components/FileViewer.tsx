
import React, { useMemo, useEffect } from 'react';
import { DecryptedFile } from '../types';

interface FileViewerProps {
  file: DecryptedFile;
  onClose: () => void;
}

const FileViewer: React.FC<FileViewerProps> = ({ file, onClose }) => {
  const url = useMemo(() => URL.createObjectURL(file.data), [file.data]);

  // Clean up URL on unmount
  useEffect(() => {
    return () => URL.revokeObjectURL(url);
  }, [url]);

  const renderContent = () => {
    if (file.type.startsWith('image/')) {
      return (
        <div className="flex justify-center items-center h-full p-4 md:p-10">
          <img 
            src={url} 
            alt={file.name} 
            className="max-w-full max-h-[60vh] md:max-h-[75vh] rounded-[32px] shadow-2xl object-contain bg-white border border-slate-100" 
          />
        </div>
      );
    }

    if (file.type.startsWith('video/')) {
      return (
        <div className="flex justify-center items-center h-full p-4 md:p-10">
          <video 
            src={url} 
            controls 
            className="max-w-full max-h-[60vh] md:max-h-[75vh] rounded-[32px] shadow-2xl bg-black" 
          />
        </div>
      );
    }

    if (file.type === 'application/pdf') {
      return (
        <div className="w-full h-[65vh] md:h-[80vh] bg-slate-100 rounded-[32px] overflow-hidden shadow-inner border border-slate-200">
           <iframe 
            src={url} 
            className="w-full h-full border-0" 
            title={file.name} 
          />
        </div>
      );
    }

    if (file.type.startsWith('text/')) {
      return (
        <div className="bg-slate-50 p-8 md:p-12 rounded-[40px] border border-slate-200 shadow-inner max-h-[60vh] overflow-auto">
           <div className="flex items-center gap-4 mb-8 text-indigo-600">
             <span className="material-symbols-outlined text-3xl">terminal</span>
             <h4 className="font-black uppercase tracking-[0.3em] text-xs">Decrypted Data Buffer</h4>
           </div>
           <div className="font-mono text-sm text-slate-800 leading-relaxed bg-white p-6 rounded-3xl border border-slate-100 mb-8">
             <span className="text-indigo-400 font-bold">$ cat {file.name}</span>
             <p className="mt-4 opacity-70 italic">[System Note: Large document preview limited for performance. Please download to view full content.]</p>
           </div>
           <div className="p-6 bg-indigo-50 rounded-3xl border border-indigo-100 text-indigo-700 text-sm flex items-start gap-4">
             <span className="material-symbols-outlined text-indigo-500">info</span>
             <p className="font-bold leading-relaxed">Security Recommendation: Once verified, download and store the original file in a separate secure location.</p>
           </div>
        </div>
      );
    }

    return (
      <div className="py-20 text-center flex flex-col items-center">
        <div className="w-24 h-24 bg-slate-100 rounded-[40px] flex items-center justify-center text-slate-300 mb-8">
          <span className="material-symbols-outlined text-5xl">inventory_2</span>
        </div>
        <p className="text-slate-900 font-black text-2xl mb-2 tracking-tight">Access Granted</p>
        <p className="text-slate-400 font-bold text-sm uppercase tracking-widest max-w-xs leading-loose">
          Type: {file.type || 'Binary Stream'} <br/>
          Content verification passed. This format requires local download for processing.
        </p>
      </div>
    );
  };

  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 lg:p-12">
      {/* MD3 Scrim */}
      <div 
        className="absolute inset-0 bg-slate-900/70 backdrop-blur-xl transition-all duration-500 animate-in fade-in"
        onClick={onClose}
      />
      
      {/* MD3 Dialog Surface */}
      <div className="relative bg-white rounded-[48px] w-full max-w-6xl shadow-3xl flex flex-col max-h-[92vh] overflow-hidden animate-in zoom-in-95 fade-in duration-500 ring-1 ring-white/20">
        
        {/* Header Bar */}
        <div className="px-6 py-5 md:px-10 md:py-8 border-b border-slate-100 flex items-center justify-between bg-white/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-5 min-w-0">
            <div className="w-14 h-14 bg-indigo-50 rounded-[20px] flex items-center justify-center text-indigo-600 flex-shrink-0 shadow-sm">
               <span className="material-symbols-outlined text-3xl font-bold">verified</span>
            </div>
            <div className="min-w-0">
              <h3 className="font-black text-slate-900 truncate pr-6 text-xl tracking-tight leading-tight">{file.name}</h3>
              <p className="text-[10px] text-indigo-400 uppercase font-black tracking-[0.2em] mt-1">{file.type || 'Encrypted Archive'}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={handleDownload}
              className="hidden md:flex h-14 px-8 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-black rounded-full transition-all items-center gap-3 shadow-xl shadow-indigo-100 active:scale-95"
            >
              <span className="material-symbols-outlined text-[20px]">download</span>
              Download
            </button>
            <button 
              onClick={onClose}
              className="p-4 text-slate-400 hover:text-slate-900 rounded-full hover:bg-slate-100 transition-all flex-shrink-0"
            >
              <span className="material-symbols-outlined text-3xl">close</span>
            </button>
          </div>
        </div>

        {/* Content Region */}
        <div className="flex-1 overflow-auto bg-slate-50/40">
          <div className="max-w-5xl mx-auto">
            {renderContent()}
          </div>
        </div>

        {/* Mobile Action Bar */}
        <div className="md:hidden p-5 border-t border-slate-100 bg-white shadow-[0_-10px_30px_rgba(0,0,0,0.03)]">
          <button 
            onClick={handleDownload}
            className="w-full h-16 bg-indigo-600 hover:bg-indigo-700 text-white text-base font-black rounded-[24px] transition-all flex items-center justify-center gap-3 active:scale-[0.98]"
          >
            <span className="material-symbols-outlined">download</span>
            Download Original
          </button>
        </div>
      </div>
    </div>
  );
};

export default FileViewer;
